import React, { Component } from "react";
import { Row, Col, Container, Form, Button, FormGroup } from "react-bootstrap";
import { NavLink } from "react-router-dom";

export default class RestaurantTile extends Component {
  render() {
    return (
      <Container>
        <h1>{this.props.restaurant.name}</h1>
        <h2>{this.props.restaurant.location}</h2>
        <h2>Price: {this.props.restaurant.price}</h2>
        <h2>{this.props.restaurant.image_link}</h2>
        {/* link to book the restaurant */}
      </Container>
    );
  }
}
