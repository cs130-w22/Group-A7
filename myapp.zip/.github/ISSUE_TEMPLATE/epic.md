---
name: Epic
about: Describe an epic
title: ''
labels: 'epic'
assignees: ''

---

## Epic
Describe the requirements of the epic.

## User Stories
- [ ] story #1
- [ ] story #4
- [ ] story #6
