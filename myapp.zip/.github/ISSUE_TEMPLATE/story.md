---
name: Story
about: Describe a feature, or an enhancement
title: ''
labels: 'story'
assignees: ''

---

## User Story
As a **[Role]**, I would like **[Requirement]** so that **[Reason]**.

## Detailed Description
Provide additional details and context.

## Acceptance Criteria
- [ ] Given **[Condition]**, then **[Expected Result]**
- [ ] Given **[Condition]**, then **[Expected Result]**
- [ ] Given **[Condition]**, then **[Expected Result]**
